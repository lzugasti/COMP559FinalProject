#pragma once
#define _USE_MATH_DEFINES
#include <cmath>

#include <vector>

#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/fwd.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <GL/glew.h>
#include "Voxel.hpp"

typedef glm::vec<2, double> vec2;
/**
 * Voxel class that contains voxel properties (e.g., mass), 
 * initial positions and velocities, current position and velocities 
 * and a force accumulator for computing the total force acting on this voxel.
 * @author Zugasti
 */
class Shape{
public:
    /** Identifies this particles position in the particle list */
    int index;

    bool pinned = false;

    std::vector<Voxel*> voxels;
    double voxelRadius = 25;

    glm::vec3 color{ 0.0f, 0.95f, 0.0f };

    double mass;
    double inertia;

    vec2 p;
    double angle;
    vec2 v;
    double angularV;
    vec2 vTemp;

    vec2 p0;
    double angle0;
    vec2 v0;
    double angularV0;
    vec2 f;

    /** Default constructor */
    void createShapePrefabricated(int shapeId)
    {
        switch (shapeId)
        {
        case 1: 
            this->voxels.push_back(new Voxel(0, 0, voxelRadius));
            break;

        case 2:
            this->voxels.push_back(new Voxel(0, 0, voxelRadius));
            this->voxels.push_back(new Voxel(50, 0, voxelRadius));
            break;

        case 3:
            this->voxels.push_back(new Voxel(0, 0, voxelRadius));
            this->voxels.push_back(new Voxel(50, 0, voxelRadius));
            this->voxels.push_back(new Voxel(50, 50, voxelRadius));
            break;

        default:
            break;
        }
    }

    /**
     * Creates a particle with the given position and velocity
     * @param x
     * @param y
     * @param vx
     * @param vy
     */
    Shape( double x, double y, double vx, double vy, double angle, double angularV, double r, double g, double b, double voxelRadius, int shapeId) : vTemp(0, 0), v(0, 0) {
        p0 = vec2(x, y);
        v0 = vec2(vx, vy);
        angle0 = angle;
        angle0 = angularV;
        reset();
        this->angle = angle;
        this->angularV = angularV;
        this->color.r = r;
        this->color.g = g;
        this->color.b = b;
        this->voxelRadius = voxelRadius;
        createShapePrefabricated(shapeId);
        this->mass = getMass();
        adjustVoxelsToCenterOfMass();
        this->inertia = getInertia();
     }

    double getMass()
    {
        double m = 0;
        for each (Voxel* v in voxels)
        {
            m += v->mass;
        }
        return m;
    }

    double getInertia()
    {
        double i = 0;
        for each (Voxel * v in voxels)
        {
            double dSquared = glm::dot(v->pRelative, v->pRelative);
            //i += (v->mass / 12.0) * (2*(2*voxelRadius) * (2*voxelRadius)) + v->mass * dSquared;
            i += (v->mass / 12.0) * (2*(2*voxelRadius) * (2*voxelRadius)) + v->mass * dSquared;
            //i += 0.5 * v->mass * voxelRadius * voxelRadius + v->mass * dSquared;
            //i += 0.5 * v->mass * voxelRadius * voxelRadius;
            //i += 0.5 * v->mass * voxelRadius * voxelRadius *glm::max(1.0, glm::sqrt(glm::dot(v->pRelative, v->pRelative)));
        }
        return i;
    }

    void adjustVoxelsToCenterOfMass()
    {
        cout << "Adjusting center of mass" << endl;
        vec2 cm = vec2(0.0, 0.0);
        for each (Voxel * v in voxels)
        {
            cm += v->mass * v->p0Relative;
        }
        cm = cm / this->mass;
        
        for each (Voxel * v in voxels)
        {
            v->p0Relative = v->p0Relative - cm;
            v->pRelative = v->pRelative - cm;
        }
    }

    /**
     * Resets the position of this particle
     */
    void reset() {
        p = p0;
        v = v0;
        f = vec2(0, 0);
    }

    /**
     * Clears all forces acting on this particle
     */
    void clearForce() {
        f = vec2(0, 0);
    }

    /**
     * Adds the given force to this particle
     * @param force
     */
    void addForce(vec2 force) {
        f += force;
    }

    /**
    * Display the current voxel on screen
    */
    void display() {
        //cout << "Displaing shape: " << index << endl;
        glm::mat2 rotation;
        rotation[0][0] = glm::cos(angle);
        rotation[0][1] = -glm::sin(angle);
        rotation[1][0] = glm::sin(angle);
        rotation[1][1] = glm::cos(angle);

        for each (Voxel* v in voxels)
        {
            v->display(rotation, p, color);
        }
    }

    /**
     * Computes the distance of another voxel to this voxel
     * @param x
     * @param y
     * @return the distance
     */
    bool checkCollisionWithWalls(double height, double width, double eps, double e)
    {
        glm::mat2 rotation;
        rotation[0][0] = glm::cos(angle);
        rotation[0][1] = -glm::sin(angle);
        rotation[1][0] = glm::sin(angle);
        rotation[1][1] = glm::cos(angle);

        for each (Voxel * vox in voxels)
        {
            vec2 vpos = this->p + (vec2)(rotation*vox->pRelative);
            if (vpos.y + voxelRadius >= height - eps)
            {
                vec2 n = glm::vec2(0.0, 1.0);

                // moving away, so no collision
                if (glm::dot(this->v, -n) > eps)
                    continue;

                double J = -(1 + e) * glm::dot(v, n) / (glm::dot(n, n) * (1 / mass));

                // Update velocities
                v = v + (J / mass) * n;
            }

            if (vpos.x + voxelRadius >= width - eps)
            {
                vec2 n = glm::vec2(1.0, 0.0);

                // moving away, so no collision
                if (glm::dot(this->v, -n) > eps)
                    continue;

                double J = -(1 + e) * glm::dot(v, n) / (glm::dot(n, n) * (1 / mass));

                // Update velocities
                v = v + (J / mass) * n;
            }


            if (vpos.x - voxelRadius <= eps)
            {
                vec2 n = glm::vec2(-1.0, 0.0);

                // moving away, so no collision
                if (glm::dot(this->v, -n) > eps)
                    continue;

                double J = -(1 + e) * glm::dot(v, n) / (glm::dot(n, n) * (1 / mass));

                // Update velocities
                v = v + (J / mass) * n;
            }
            
        }
        /*if (shape->p.y + vox->radius >= height - eps)
        {
            vec2 n = glm::vec2(0.0, 1.0);
            double e = 1;
            double J = -(1 + e) * glm::dot(vox->v, n) / (glm::dot(n, n) * (1 / vox->mass));

            // Update velocities
            vox->v = vox->v + (J / vox->mass) * n;
        }

        if (vox->p.x + vox->radius >= width - eps)
        {
            vec2 n = glm::vec2(1.0, 0.0);
            double e = 1;
            double J = -(1 + e) * glm::dot(vox->v, n) / (glm::dot(n, n) * (1 / vox->mass));

            // Update velocities
            vox->v = vox->v + (J / vox->mass) * n;
        }


        if (vox->p.x - vox->radius <= eps)
        {
            vec2 n = glm::vec2(1.0, 0.0);
            double e = 1;
            double J = -(1 + e) * glm::dot(vox->v, n) / (glm::dot(n, n) * (1 / vox->mass));

            // Update velocities
            vox->v = vox->v + (J / vox->mass) * n;
        }*/
        return false;
    }

    bool checkCollisionWithWallsWithAngular(double height, double width, double eps, double e)
    {
        glm::mat2 rotation;
        rotation[0][0] = glm::cos(angle);
        rotation[0][1] = -glm::sin(angle);
        rotation[1][0] = glm::sin(angle);
        rotation[1][1] = glm::cos(angle);

        std::vector<vec2> impulses;
        std::vector<vec2> rPerps;
        for each (Voxel * vox in voxels)
        {
            vec2 vpos = this->p + (vec2)(rotation * vox->pRelative);
            if (vpos.y + voxelRadius >= height - eps)
            {
                vec2 n = glm::vec2(0.0, 1.0);
                vec2 r = this->p - vec2(vpos.x, vpos.y+voxelRadius);

                vec2 rPerp = vec2(-r.y, r.x);

                vec2 angularV = rPerp * this->angularV;
                
                vec2 relativeVelocity = (this->v + angularV);

                // moving away, so no collision
                if (glm::dot(relativeVelocity, n) < -eps)
                    continue;


                double rdotn = glm::dot(rPerp, n);
                double J = -(1 + e) * glm::dot(relativeVelocity, n) / ((1 / (mass) +(rdotn * rdotn / (inertia))));


                vec2 impulse = J * n;
                impulses.push_back(impulse);
                rPerps.push_back(rPerp);
            }

            /*if (vpos.x + voxelRadius >= width - eps)
            {
                vec2 n = glm::vec2(1.0, 0.0);

                // moving away, so no collision
                if (glm::dot(this->v, -n) > eps)
                    continue;

                double J = -(1 + e) * glm::dot(v, n) / (glm::dot(n, n) * (1 / mass));

                // Update velocities
                v = v + (J / mass) * n;
            }


            if (vpos.x - voxelRadius <= eps)
            {
                vec2 n = glm::vec2(-1.0, 0.0);

                // moving away, so no collision
                if (glm::dot(this->v, -n) > eps)
                    continue;

                double J = -(1 + e) * glm::dot(v, n) / (glm::dot(n, n) * (1 / mass));

                // Update velocities
                v = v + (J / mass) * n;
            }*/

        }

        for (int i = 0; i < impulses.size(); i++)
        {
            vec2 impulse = impulses[i] / (double)impulses.size();
            v = v + impulse / mass;
            angularV = angularV + glm::dot(rPerps[i], impulse) / inertia;
        } 
        return false;
        
    }

    bool checkCollision(Shape *s, std::vector<vec2> *collisions, std::vector<vec2> *normals, std::vector<vec2>* relativeVelocities, double eps) {
        bool hadCollision = false;
        glm::mat2 rotation1;
        rotation1[0][0] = glm::cos(angle);
        rotation1[0][1] = -glm::sin(angle);
        rotation1[1][0] = glm::sin(angle);
        rotation1[1][1] = glm::cos(angle);

        glm::mat2 rotation2;
        rotation2[0][0] = glm::cos(s->angle);
        rotation2[0][1] = -glm::sin(s->angle);
        rotation2[1][0] = glm::sin(s->angle);
        rotation2[1][1] = glm::cos(s->angle);

        for each (Voxel *v1 in voxels)
        {
            for each (Voxel * v2 in s->voxels)
            {
                vec2 v1pos = this->p + (vec2)(rotation1*v1->pRelative);
                vec2 v2pos = s->p + (vec2)(rotation2 * v2->pRelative);
                vec2 diff = v1pos - v2pos;
                double distance = (float)sqrt(diff.x * diff.x + diff.y * diff.y) - 2 * voxelRadius;
                if (distance < eps)
                {
                    vec2 position = (v1pos + v2pos) / 2.0;
                    vec2 normal = v1pos - v2pos;
                    vec2 relativeVelocity = this->v - s->v;
                    collisions->push_back(position);
                    normals->push_back(normal);
                    relativeVelocities->push_back(relativeVelocity);
                    hadCollision = true;
                }
            }
        }
        return hadCollision;
    }

    bool checkCollisionAngular(Shape* s, std::vector<vec2>* collisions, std::vector<vec2>* normals, std::vector<vec2>* relativeVelocities, std::vector<vec2>* angularV1s, std::vector<vec2>* angularV2s, std::vector<vec2>* r1perps, std::vector<vec2>* r2perps, std::vector<vec2>* r1s, std::vector<vec2>* r2s, double eps) {
        bool hadCollision = false;
        glm::mat2 rotation1;
        rotation1[0][0] = glm::cos(angle);
        rotation1[0][1] = -glm::sin(angle);
        rotation1[1][0] = glm::sin(angle);
        rotation1[1][1] = glm::cos(angle);

        glm::mat2 rotation2;
        rotation2[0][0] = glm::cos(s->angle);
        rotation2[0][1] = -glm::sin(s->angle);
        rotation2[1][0] = glm::sin(s->angle);
        rotation2[1][1] = glm::cos(s->angle);

        for each (Voxel * v1 in voxels)
        {
            for each (Voxel * v2 in s->voxels)
            {
                vec2 v1pos = this->p + (vec2)(rotation1 * v1->pRelative);
                vec2 v2pos = s->p + (vec2)(rotation2 * v2->pRelative);
                vec2 diff = v1pos - v2pos;
                double distance = (float)sqrt(diff.x * diff.x + diff.y * diff.y) - 2 * voxelRadius;
                if (distance < eps)
                {
                    vec2 position = (v1pos + v2pos) / 2.0;
                    vec2 normal = v1pos - v2pos;

                    vec2 r1 = position - this->p;
                    vec2 r2 = position - s->p;

                    vec2 r1Perp = vec2(-r1.y, r1.x);
                    vec2 r2Perp = vec2(-r2.y, r2.y);

                    vec2 angularV1 = r1Perp * this->angularV;
                    vec2 angularV2 = r2Perp * s->angularV;

                    vec2 relativeVelocity = (this->v + angularV1) - (s->v + angularV2);
                    collisions->push_back(position);
                    normals->push_back(normal);
                    angularV1s->push_back(angularV1);
                    angularV2s->push_back(angularV2);
                    r1perps->push_back(r1Perp);
                    r2perps->push_back(r2Perp);
                    r1s->push_back(r1);
                    r2s->push_back(r2);
                    relativeVelocities->push_back(relativeVelocity);
                    hadCollision = true;
                }
            }
        }
        return hadCollision;
    }
};

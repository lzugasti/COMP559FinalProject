#pragma once
#include <vector>

#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "GLSL.h"

#include "Particle.hpp"
#include "Spring.hpp"
#include "BendingSpring.hpp"
#include "RobustCCD.hpp"
#include "Voxel.hpp"
#include "CollisonHandler.hpp"

typedef glm::vec<2, double> vec2;

using namespace std;

/**
 * Implementation of a simple particle system
 * @author kry & Mercier-Aubin
 */
class VoxelSystem  {
    
public:
    string name = "";
    std::vector<Shape*> shapes;
    CollisionHandler collisionHandler;


    /**
     * Creates an empty particle system
     */
    VoxelSystem(){
    }

    ~VoxelSystem() {
        for (int i = 1; i < shapes.size(); ++i) {
            delete shapes[i];
        }
    }
    
    /**
     * Resets the positions of all voxels
     */
    void resetVoxels() {
        for (Shape* s : shapes) {
            s->reset();
        }
        time = 0;
    }
    
    /**
     * Deletes all voxels
     */
    void clearVoxels() {
        for (Shape* s : shapes) { delete s; }
        shapes.clear();
    }
    
    /** Elapsed simulation time */
    double time = 0;
        
    /**
     *  Compute nodal forces using gravity and spring contributions
     */
    void computeForce() {

        // reset forces and set gravity
        for (Shape* s : shapes) {
            if (s->pinned)
                continue;
            vec2 viscousDampingForce = -viscousDamping * s->mass * s->v;
            s->f = vec2(0, 1) * s->mass * (useGravity ? gravity : 0)  + viscousDampingForce;
        }
    }
    
    void stepVelocities(float h) {
        for (Shape* s : shapes) {
            if (s->pinned)
                continue;
            s->angle += h * s->angularV;
            s->v += (h / s->mass) * s->f;
        }
    }

    /**
     * Update the positions with current velocities given the time step
     * @param h time step
     */
    void stepPositions(double h) {
        for (Shape* s : shapes) {
            if (s->pinned)
                continue;
            s->p += h * s->v;
            s->f = vec2(0, 0);
        }
    }

    /** Time in seconds that was necessary to advance the system */
    float computeTime = 0;
    
    /**
     * Advances the state of the system
     * @param elapsed
     */
    void advanceTime( double elapsed ) {
        //cout << "Time advanced by: " << elapsed << endl;
        double now = glfwGetTime();
        
        // Simple symplectic Euler integration
        computeForce();
        stepVelocities(elapsed);
        //collisionHandler.applyImpulses(elapsed, &shapes, width, height);
        collisionHandler.applyImpulsesWithAngular(elapsed, &shapes, width, height);
        stepPositions(elapsed);
        
        time += elapsed;
        computeTime = (glfwGetTime() - now);
    }
    
    /*void filter(VectorXf& v) {
        for ( Particle* p : particles ) {
            if ( !p->pinned ) continue;
            v[ p->index*2+0] = 0;
            v[ p->index*2+1] = 0;
        }
    }*/


    Shape* createShape(float x, float y, float vx, float vy, float angle, float angularVelocity, double r, double g, double b, double voxelRadius, int shapeId) {
        Shape* v = new Shape(x, y, vx, vy, angle, angularVelocity, r, g, b, voxelRadius, shapeId);
        v->index = shapes.size();
        shapes.push_back(v);
        return v;
    }
    
    void remove( Shape* v ) {

    	shapes.erase( std::remove(shapes.begin(), shapes.end(), v ) );
    	// reset indices of each particle :(
    	for ( int i = 0 ; i < shapes.size(); i++ ) {
            shapes[i]->index = i;
    	}
    }
    
    void init() {
        // do nothing
    }

    int height = 0;
    int width = 0;

    void display() {

        glClear(GL_COLOR_BUFFER_BIT);
        for each (Shape *s in shapes)
        {
            s->display();
        }
    }
    
    bool useGravity = true;
    double gravity = 9.8;
    double springStiffness = 100;
    double springDamping = 0;
    double viscousDamping = 0;
    double bendingStiffness = 1e3;
};